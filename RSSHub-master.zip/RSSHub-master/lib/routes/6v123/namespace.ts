import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '6v 电影',
    url: 'hao6v.cc',
    lang: 'zh-CN',
};
