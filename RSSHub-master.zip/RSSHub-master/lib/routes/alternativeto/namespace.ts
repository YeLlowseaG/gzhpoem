import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'AlternativeTo',
    url: 'www.alternativeto.net',
    lang: 'en',
};
