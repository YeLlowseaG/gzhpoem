import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '500px 摄影社区',
    url: '500px.com.cn',
    lang: 'zh-CN',
};
