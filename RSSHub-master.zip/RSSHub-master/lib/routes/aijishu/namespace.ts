import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '极术社区',
    url: 'www.aijishu',
    lang: 'zh-CN',
};
