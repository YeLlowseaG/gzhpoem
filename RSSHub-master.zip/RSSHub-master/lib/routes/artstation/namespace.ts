import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'ArtStation',
    url: 'www.artstation.com',
    lang: 'en',
};
