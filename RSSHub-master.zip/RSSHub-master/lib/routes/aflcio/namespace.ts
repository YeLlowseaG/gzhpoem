import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'AFL-CIO',
    url: 'aflcio.org',
    categories: ['other'],
    description: '',
    lang: 'en',
};
