import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'The Australian Financial Review',
    url: 'afr.com',
    lang: 'en',
};
