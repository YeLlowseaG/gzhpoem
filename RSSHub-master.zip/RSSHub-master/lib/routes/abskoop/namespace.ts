import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'A 姐分享',
    url: 'nsfw.abskoop.com',
    lang: 'zh-TW',
};
