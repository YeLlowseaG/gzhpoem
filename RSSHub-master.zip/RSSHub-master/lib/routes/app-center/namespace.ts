import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'App Center',
    url: 'install.appcenter.ms',
    lang: 'en',
};
