import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'A List Apart',
    url: 'alistapart.com',
    lang: 'en',
};
