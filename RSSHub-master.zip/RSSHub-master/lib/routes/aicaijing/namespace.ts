import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'AI 财经社',
    url: 'www.aicaijing.com',
    lang: 'zh-CN',
};
