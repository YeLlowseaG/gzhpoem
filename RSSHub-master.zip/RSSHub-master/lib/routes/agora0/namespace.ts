import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'AG⓪RA',
    url: 'agorahub.github.io',
    lang: 'en',
};
