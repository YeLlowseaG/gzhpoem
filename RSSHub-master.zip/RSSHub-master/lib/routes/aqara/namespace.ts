import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'Aqara',
    url: 'aqara.com',
    lang: 'zh-CN',
};
