import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '4KUP',
    url: '4kup.net',
    description: '4KUP - Beautiful Girls Collection',
    lang: 'en',
};
