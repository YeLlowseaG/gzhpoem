const SUB_NAME_PREFIX = '4KUP';
const SUB_URL = 'https://4kup.net/';

export { SUB_NAME_PREFIX, SUB_URL };
