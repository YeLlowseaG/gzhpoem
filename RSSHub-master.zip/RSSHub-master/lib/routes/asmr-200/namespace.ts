import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'ASMR Online',
    url: 'asmr-200.com',
    lang: 'zh-CN',
};
