import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '3k-Switch游戏库',
    url: 'www.3kns.com',
    lang: 'zh-CN',
};
