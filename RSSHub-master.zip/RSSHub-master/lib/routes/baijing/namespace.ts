import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '白鲸出海',
    url: 'baijing.cn',
    description: '白鲸出海',
    lang: 'zh-CN',
};
