import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'Aljazeera',
    url: 'aljazeera.com',
    lang: 'en',
};
