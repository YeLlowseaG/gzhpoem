import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'Amazon',
    url: 'amazon.com',
    lang: 'en',
};
