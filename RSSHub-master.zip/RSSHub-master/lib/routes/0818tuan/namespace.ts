import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '0818 团',
    url: '0818tuan.com',
    lang: 'zh-CN',
};
