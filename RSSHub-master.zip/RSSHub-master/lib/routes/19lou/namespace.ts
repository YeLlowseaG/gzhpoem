import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '19 楼',
    url: '19lou.com',
    lang: 'zh-CN',
};
