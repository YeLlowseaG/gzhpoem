import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '30 Seconds of code',
    url: 'www.30secondsofcode.org',
    lang: 'en',
};
