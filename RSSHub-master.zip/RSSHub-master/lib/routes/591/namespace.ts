import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '591 Rental house',
    url: 'rent.591.com.tw',
    lang: 'zh-TW',
};
