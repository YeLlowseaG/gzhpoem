import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'AInvest',
    url: 'ainvest.com',
    lang: 'en',
};
