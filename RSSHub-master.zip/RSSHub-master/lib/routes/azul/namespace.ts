import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'Azul',
    url: 'azul.com',
    categories: ['programming'],
    description: '',
    lang: 'en',
};
