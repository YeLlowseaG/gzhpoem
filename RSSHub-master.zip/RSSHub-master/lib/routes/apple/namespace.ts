import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'Apple',
    url: 'apple.com',
    lang: 'en',
};
