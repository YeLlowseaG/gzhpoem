import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'Asianfanfics',
    url: 'asianfanfics.com',
    lang: 'en',
};
