import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '经济 50 人论坛',
    url: '50forum.org.cn',
    lang: 'zh-CN',
};
