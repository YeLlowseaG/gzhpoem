import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'AppleInsider',
    url: 'appleinsider.com',
    lang: 'en',
};
