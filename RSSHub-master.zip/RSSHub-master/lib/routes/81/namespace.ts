import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '中国军网',
    url: '81.cn',
    categories: ['government'],
    description: '',
    lang: 'zh-CN',
};
