import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'Android',
    url: 'developer.android.com',
    lang: 'en',
};
