import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '空气质量',
    url: 'aqicn.org',
    lang: 'zh-CN',
};
