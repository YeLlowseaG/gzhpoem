import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '36kr',
    url: '36kr.com',
    lang: 'zh-CN',
};
