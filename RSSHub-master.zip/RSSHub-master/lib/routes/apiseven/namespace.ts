import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '支流科技',
    url: 'apiseven.com',
    lang: 'zh-CN',
};
