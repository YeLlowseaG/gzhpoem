import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '巴卡漫画',
    url: 'bakamh.com',
    categories: ['anime'],
    lang: 'zh-CN',
};
