const SUB_NAME_PREFIX = '4KHD';
const SUB_URL = 'https://www.4khd.com/';

export { SUB_NAME_PREFIX, SUB_URL };
