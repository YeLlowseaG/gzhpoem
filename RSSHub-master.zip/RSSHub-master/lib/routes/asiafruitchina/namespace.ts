import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '亚洲水果',
    url: 'asiafruitchina.net',
    categories: ['new-media'],
    description: '',
    lang: 'zh-CN',
};
