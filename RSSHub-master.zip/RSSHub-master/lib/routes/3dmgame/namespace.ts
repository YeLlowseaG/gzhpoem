import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '3DMGame',
    url: '3dmgame.com',
    lang: 'zh-CN',
};
