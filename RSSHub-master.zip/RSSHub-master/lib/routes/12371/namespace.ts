import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '共产党员网',
    url: 'www.12371.cn',
    categories: ['government'],
    lang: 'zh-CN',
};
