import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '7mmtv',
    url: '7mmtv.tv',
    lang: 'zh-CN',
};
