import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'Bandcamp',
    url: 'bandcamp.com',
    lang: 'en',
};
