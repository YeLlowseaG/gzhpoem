import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '12306',
    url: 'kyfw.12306.cn',
    lang: 'zh-CN',
};
