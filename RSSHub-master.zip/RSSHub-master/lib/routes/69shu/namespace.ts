import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: '69书吧',
    url: '69shuba.cx',
    lang: 'zh-CN',
};
