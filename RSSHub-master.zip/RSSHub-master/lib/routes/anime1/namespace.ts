import type { Namespace } from '@/types';

export const namespace: Namespace = {
    name: 'Anime1',
    url: 'anime1.me',
    lang: 'zh-TW',
};
