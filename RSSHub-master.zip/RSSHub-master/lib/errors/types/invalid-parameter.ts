class InvalidParameterError extends Error {
    name = 'InvalidParameterError';
}

export default InvalidParameterError;
