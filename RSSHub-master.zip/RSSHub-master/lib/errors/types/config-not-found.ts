class ConfigNotFoundError extends Error {
    name = 'ConfigNotFoundError';
}

export default ConfigNotFoundError;
