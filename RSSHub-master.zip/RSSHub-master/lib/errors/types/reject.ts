class RejectError extends Error {
    name = 'RejectError';
}

export default RejectError;
