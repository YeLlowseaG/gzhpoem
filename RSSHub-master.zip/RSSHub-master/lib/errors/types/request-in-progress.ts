class RequestInProgressError extends Error {
    name = 'RequestInProgressError';
}

export default RequestInProgressError;
